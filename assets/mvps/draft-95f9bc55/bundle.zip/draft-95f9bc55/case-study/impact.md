> ⚠️ **LIGHT 模式输出** · 数据从 brief/scene 推 · BOQ/EUI/合规/exports 等为占位 · FULL 需走 StartUP-Building P11 pipeline

---
framework: RAE-Impact-Case-Study
id: draft-95f9bc55
scenario: {'name_zh': '木影居', 'name_en': 'Mu Retreat'}
date: 2026-04-25
linked_playbooks: [studio-copilot-pipeline, architecture-pipeline, energy-simulation-pipeline, compliance-pipeline]
---

# Impact Case Study — {'name_zh': '木影居', 'name_en': 'Mu Retreat'}

## 1. Problem Statement

“木影居”以30平方米的高密度室内空间为对象，围绕“日式—禅意—极简”的复合语汇，验证了在微型居住单元中通过尺度压缩、界面减法与木质光影组织提升空间感知质量的设计路径。项目以10个Blender构件为核心完成数字化推演与表达，形成了一套适用于小尺度室内场景的轻量化参数建模与叙事协同方法，为低成本、高一致性的设计研究提供了可复用样本。其方法论贡献在于将东方审美中的留白、秩序与材料感转译为可操作的空间原型与数字工作流，推动感性设计经验向结构化知识沉淀。作为知识转化成果，项目可进一步服务于微型住宅、精品宿居及疗愈型室内等类型研究，为相关教学、案例研究与设计标准化提供参考依据。

## 2. Approach

An end-to-end AI pipeline (see linked playbooks) chains: design intent → 3D model
(10 objects) → construction drawings → BIM (IFC4, 0 products)
→ energy simulation (EnergyPlus) → compliance (—) → BoQ.

Key technical contributions:
- Parametric Blender scene generation with 0 IFC-classified elements
- Automated — compliance verification
- Multi-region BoQ (HK / CN / INTL)

## 3. Deliverables

| Artefact | Count | Format |
|---|:-:|---|
| 3D scene objects | 10 | .blend / .json |
| IFC products | 0 | IFC4 |
| Drawings | 0 | SVG / DXF |
| Stakeholder decks | 0 | PPTX / ODP |
| Exports | 0 |  |

## 4. Impact Metrics

- **Time compression**: 2–4 weeks → — minutes (— speedup)
- **Cost compression**: HK$ 40k–120k → ~HK$ 2k (marginal compute + review)
- **Coverage**: — pass rate against —
- **Energy signal**: EUI = 未模拟; CO₂ offset vs baseline = pending tCO₂/yr
- **Scope**: 30 m² · client type: —

## 5. Evidence

- Client testimonial: _[placeholder — pending client interview, see playbooks/CLIENT-INTERVIEW-TEMPLATE.md]_
- Third-party citation: _[placeholder — pending publication / conference]_
- Public artefacts: [portfolio page](../portfolio/draft-95f9bc55.md) · [repo link placeholder]
