> ⚠️ **LIGHT 模式输出** · 数据从 brief/scene 推 · BOQ/EUI/合规/exports 等为占位 · FULL 需走 StartUP-Building P11 pipeline

---
layout: portfolio
id: draft-95f9bc55
tier: interior
tags: [日式, 禅意, 极简]
cover: thumbs/hero.jpg
---

# {'name_zh': '木影居', 'name_en': 'Mu Retreat'}

![hero](thumbs/hero.jpg)

## 核心指标

| 面积 | 造价 | EUI | 合规 |
|:-:|:-:|:-:|:-:|
| 30 m² | — | 未模拟 | — |

## 方案亮点

《木影居》是一个30平方米的小宅，我们希望它像一处可随时抽离日常的安静角落，把日式的克制、禅意的留白与极简的纯净收进同一个空间里。居住者无论是独处放空、静坐阅读，还是与亲友轻声小聚，都能在温润木色与柔和光影之间，自然放慢节奏。设计以简洁的线条、低饱和材质和有序收纳维持空间的清爽，让小尺度也能呈现从容呼吸感。最让人记住的，是光线落在木质表面时形成的层层影子，像一幅会随时间流动的静谧风景。

## 作品展示

_[缩略图未生成]_

## 交付清单

- 3D 模型 · 0 件套（）
- 图纸 · 0 张平面 · 0 立面 · 0 剖面
- 0 份角色定制方案书
- Blender scene: 10 objects · IFC4 products: 0

[联系我们 · 要类似方案 →](mailto:studio@example.com?subject=draft-95f9bc55)
