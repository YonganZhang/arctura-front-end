# 合规报告 · HK BEEO 2021（占位）

> ⚠️ 本报告为脚本占位 · 非真 OpenStudio `report compliance` 产出 · 仅示意格式。
> 正式合规需在 Mac/Linux 跑 `cli-anything-openstudio-cli report compliance --code HK`。

## 项目

- **名称**: 校长办公室 · 日式禅风
- **面积**: 30 ㎡
- **code**: HK_BEEO_BEC_2021 (_ref: BEC 2021 §5.3.2)

## 检查项

| 项 | 值 | 限值 | 单位 | 状态 | 备注 |
|---|---|---|---|---|---|
| EUI (advisory) | 45.0 | 150 | kWh/m²·yr | ✓ advisory | 30% of limit |
| Wall U-value | 0.55 | 1.8 | W/m²K | ✓ pass | |
| Roof U-value | 0.5 | 1.8 | W/m²K | ✓ pass | |
| Window U-value | 2.0 | 5.5 | W/m²K | ✓ pass | |
| WWR | 0.3 | < 0.7 | ratio | ✓ pass | SHGC 分档 |
| Lighting density | 8 | 11 | W/m² | ✓ pass | |

**Verdict**: PASS (advisory · 无强制 EUI 上限)
