# 方案对比矩阵 · diff-matrix.md

6 维度对比（StartUP-Building/CLAUDE.md 必含维度 · 由 _build/variant_presets.py 生成）

| 维度 | v1-essential 基础方案 | v2-standard 标准方案 | v3-premium 高端方案 |
|---|---|---|---|
| **1. 风格定调** | japandi· 克制 | japandi· 标准 | japandi· 软包升级 + 定制灯具 |
| **2. EUI** | 50.0 kWh/m²·yr · 年耗 1500.0 kWh | 45.0 kWh/m²·yr · 年耗 1350.0 kWh | 37.0 kWh/m²·yr · 年耗 1110.0 kWh |
| **3. 工料报价** | HKD 90,000 · 单方 HKD 3,000/㎡ | HKD 120,000 · 单方 HKD 4,000/㎡ | HKD 180,000 · 单方 HKD 6,000/㎡ |
| **4. 年维护** | HKD 4,000/yr | HKD 6,000/yr | HKD 9,000/yr |
| **5. 合规** | HK BEEO 2021 ✓ pass (advisory) | ✓ pass | ✓ pass |
| **6. 决策推荐** | 预算紧张 · 分校 / 分校区 | **推荐** · 主校区标准 · 功能 + 品味均衡（推荐） | 品牌旗舰 · 接待校董 / 外宾 |

## 决策理由

- **v1-essential** · 预算紧张 · 分校 / 分校区
- **v2-standard** · 主校区标准 · 功能 + 品味均衡（推荐）
- **v3-premium** · 品牌旗舰 · 接待校董 / 外宾
