# What-If 3 变体能耗对比

| Variant | Wall U | Window U | Lighting W/m² | EUI | Annual (kWh) |
|---|---|---|---|---|---|
| v1-essential | 0.6 | 2.0 | 10 | 50 | 1500 |
| v2-standard | 0.55 | 2.0 | 8 | 45 | 1350 |
| v3-premium | 0.35 | 1.2 | 6 | 37 | 1110 |

v3 相对 v1 节能 26%。单方年维护差 HKD 5,000。
