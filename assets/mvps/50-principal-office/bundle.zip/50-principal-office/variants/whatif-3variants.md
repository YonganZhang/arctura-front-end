# What-If 3 变体能耗对比（由 variant_presets 生成）

| Variant | Wall U | Window U | Lighting W/m² | EUI | Annual (kWh) |
|---|---|---|---|---|---|
| v1-essential | 0.65 | 2.0 | 10 | 50.0 | 1500.0 |
| v2-standard | 0.55 | 2.0 | 8 | 45.0 | 1350.0 |
| v3-premium | 0.35 | 1.2 | 6 | 37.0 | 1110.0 |

v3-premium 相对 v1-essential 节能 26%。
