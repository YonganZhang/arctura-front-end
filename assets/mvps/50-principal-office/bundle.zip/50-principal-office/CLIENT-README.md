# 校长办公室 · 日式禅风

> **Slug**: `50-principal-office` · **面积**: 30 ㎡ · **预算**: HKD 120,000 · **位置**: Hong Kong

## 设计概览

- **风格**: japandi, zen, light-oak, natural-linen, minimal, serene
- **色彩基调**: primary (#D7C4A8), secondary (#8A7A5C), accent (#2A2A2A), wall (#F5F1E8)
- **房型**: workplace · P1-interior

## 设计统计

- 家具件数：11 件
- 功能分区：3 区
- 灯光组数：3 组
- 材质库：10 项

## 文件说明

| 文件 | 用途 |
|---|---|
| `brief.json` | 设计简报（brief-interior-v1 schema） |
| `room.json` | 3D 场景数据（objects / lights / materials / cameras / assemblies） |
| `moodboard.png` + `.json` | 色板 + 风格 keywords |
| `floorplan.svg` + `.png` | 平面图（中文标注 + 比例尺） |
| `renders/` | 8 张多角度渲染 · ⚠ 需 Blender 生成 · 本机未跑 |
| `decks/deck-client.md` + `.pptx` + `.pdf` | 客户方案 PPT（Marp） |
| `energy/` | project.json + compliance-HK.md + boq-HK.md（占位 · 真跑需 OpenStudio） |
| `exports/` | GLB/FBX/IFC4 · ⚠ 需 Blender 生成 · 本机未跑 |
| `variants/v1-v3` | 3 档套餐 overlay JSON（-25% / 0 / +50%） |
| `case-study/` | portfolio/impact/sales + metrics + narrative |

## BOQ 报价（HK）

| 项目 | 数量 | 单价 |
|---|---|---|
| 大班办公桌（浅橡木） | 1 | HKD 22,000 |
| 高背校长椅（米色亚麻） | 1 | HKD 7,800 |
| 客椅（浅木框架） | 2 | HKD 2,800 |
| 整面浅木格架 | 1 | HKD 24,000 |
| 低矮立柜（奖杯陈列） | 1 | HKD 7,000 |
| 三人沙发（米白亚麻） | 1 | HKD 16,000 |
| 原木茶几 | 1 | HKD 3,800 |
| 和纸落地灯 | 1 | HKD 2,600 |
| 哑光黑铁吊灯 | 1 | HKD 3,800 |
| 米灰榻榻米地毯 | 1 | HKD 4,800 |
| **合计** | | **HKD ~122,000** |

## 利益方

- **校方决策**: 校长 + 校董会 · 关注方案风格 + 预算 + 施工周期
- **设计团队**: 看 deck-designer.md · 关注材质清单 + 3D 细节
- **施工方**: 看 exports/ + floorplan.svg · 关注尺寸 + 材料
- **运营**: 看 energy/ + maintenance 估算 · 关注长期成本

## 合规与能耗

- **EUI**: 45.0 kWh/m²·yr（< 150 限值 · advisory）
- **年耗电**: 1350.0 kWh
- **HK BEEO 2021**: PASS

## Web

https://arctura-front-end.vercel.app/project/50-principal-office

## 生成信息

- 生成时间: 2026-04-22T20:00:33.727922Z
- 生成器: `Arctura-Front-end/_build/materialize_full_mvp.py`
- 权威规则: `StartUP-Building/CLAUDE.md`（Step 0b 5 档选择器 + 必含产物清单）
- 档位: 交付档（概念 + 方案 PPT + 客户文档 · 不含 Blender 渲染）
