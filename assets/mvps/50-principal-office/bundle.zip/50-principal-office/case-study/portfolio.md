# 校长办公室 · 日式禅风 · Portfolio

## 项目定位

japandi, zen, light-oak, natural-linen, minimal, serene风格的 30 ㎡ workplace 空间改造。

## 核心亮点

- 功能分区：办公区、接待区、书柜墙
- 总预算：HKD 120,000（单方价 HKD 4,000/㎡）
- 色板：primary, secondary, accent, wall

## 设计语言

详见 [[moodboard]]（色板 · 材质 · 风格 keywords）。
