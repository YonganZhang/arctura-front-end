# 产物完成状态（对照 StartUP-Building/CLAUDE.md L405-434 必含清单）

## ✅ 已补齐（LIGHT 模式 · 本机 Python/Playwright 能做）

- [x] brief.json · room.json · moodboard.{png,json} · floorplan.{svg,png}
- [x] CLIENT-README.md · decks/deck-client.md
- [x] energy/{project.json,compliance-HK.md,boq-HK.md,boq-HK.csv}（占位 · 非真 EnergyPlus）
- [x] case-study/{portfolio,impact,sales}.md + metrics.json + narrative-*.txt
- [x] case-study/thumbs/（PIL 从 renders 缩 6 张 · 2026-04-22 晚补）
- [x] variants/v1-v3 overlay JSON（套餐前端可点切换）
- [x] variants/diff-matrix.md + whatif-3variants.md（从 VARIANT_PRESETS 共享常量生成）
- [x] renders/ 8 张（Playwright 截 Three.js · `node _build/capture_renders.mjs --slug <slug>`）

## 🔄 FULL 模式待实装（需要扩展脚本 · 基础设施已就位）

- [ ] `exports/{slug}.glb` / `.fbx` / `.obj` / `.ifc`（BIM 导出 · 需 `_build/render_with_blender.py`）
- [ ] `variants/v*/hero.png` + `renders/×4`（variant-aware Playwright · 或 Blender）
- [ ] `variants/comparison-grid-4x3.png` + `grid-row-*.png × 4`（PIL 合成 · 脚本待写）
- [ ] 照片级 Cycles 渲染（GPU 加速最佳 · 本机 CPU 慢）
- [ ] 真 EnergyPlus 能耗（需装 OpenStudio）

## 基础设施

- **Blender**：`~/.local/blender/blender-4.2.3-linux-x64/blender`（已装 · 4.2.3 LTS · 无头渲染验证）
- **Playwright**：`node_modules/@playwright/test` · chromium-1217 已下载
- **Marp**：`marp-cli` 在 path · 缺 chrome（decks/pptx 不自动跑）
- **PIL**：系统 python3 有 · 字体回退：noto-cjk / wqy-zenhei

## 下次启动入口

```bash
python3 _build/create_mvp_from_brief.py --mode light --brief X.json --slug YY-zzz
python3 _build/materialize_full_mvp.py --slug YY-zzz
node _build/capture_renders.mjs --slug YY-zzz
```

权威规则 `StartUP-Building/CLAUDE.md` L350："做不到就说 · 不静默跳" — 本 TODO 即此规则落地。
