# ⚠ Blender 产物未生成（本机无 Blender）

以下产物必须在 Mac（`/Users/kaku/Desktop/Work/CLI-Anything/`）或有 Blender 的节点上补：

- [ ] `renders/01_hero_corner.png` … 08_*.png（8 张多角度渲染 · 用 P1 Pipeline）
- [ ] `exports/{slug}.glb` / `.fbx` / `.obj` / `.mtl` / `.ifc`（5 格式导出 · 用 blender_cli model export）
- [ ] `variants/v1-essential/hero.png` + `renders/` × 4 视角
- [ ] `variants/v2-standard/hero.png` + `renders/` × 4
- [ ] `variants/v3-premium/hero.png` + `renders/` × 4
- [ ] `variants/comparison-grid-4x3.png` · `grid-row-*.png` × 4
- [ ] `case-study/thumbs/*.png`（6 张缩略图）

## 正式补齐命令（到 Mac 跑）

```bash
cd /Users/kaku/Desktop/Work/StartUP-Building
$PY playbooks/scripts/batch_all_mvps.py --only 50-principal-office
```

## 为什么本机做不到

本机是 Linux + Arctura-Front-end 前端开发环境 · 没有 Blender / OpenStudio。
权威规则 CLAUDE.md L350（执行纪律）："做不到就说 · 不要静默跳过" — 本 TODO 即此规则落地。
