# 校长办公室 · 日式禅风

- **Slug**: `50-principal-office`
- **面积**: 30 m²
- **位置**: Hong Kong
- **预算**: HKD 120,000
- **风格**: japandi, zen, light-oak, natural-linen, minimal, serene

## 内容

- `brief.json` — 原始 brief（用户 + AI 推导的参数）
- `mvp.json` — 完整 MVP 文件（scene + variants + pricing + energy + compliance）
- `scene.json` — 3D 场景数据独立版
- `assets/` — renders / hero / thumb / moodboard 等（如果有）

## 生成

由 `_build/create_mvp_from_brief.py` 产出 · 生成时间 2026-04-22T08:18:00.265623Z

## Web

在线访问：https://arctura-front-end.vercel.app/project/50-principal-office
