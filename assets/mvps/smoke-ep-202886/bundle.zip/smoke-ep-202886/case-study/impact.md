> ⚠️ **LIGHT 模式输出** · 数据从 brief/scene 推 · BOQ/EUI/合规/exports 等为占位 · FULL 需走 StartUP-Building P11 pipeline

---
framework: RAE-Impact-Case-Study
id: smoke-ep-202886
scenario: EP smoke test · 酒店大堂
date: 2026-04-24
linked_playbooks: [studio-copilot-pipeline, architecture-pipeline, energy-simulation-pipeline, compliance-pipeline]
---

# Impact Case Study — EP smoke test · 酒店大堂

## 1. Problem Statement

本项目以42平方米酒店大堂为研究型设计样本，在现代、温暖的空间命题下，建立了小尺度公共室内中“到达体验—停留感知—品牌识别”三者协同的设计框架，验证了高频接待空间中氛围营造与功能组织可被同步优化的方法路径。项目方法论上强调以室内叙事、界面层次与灯光/材质协同为核心的整合策略，并通过10个三维对象的数字化构成测试，形成适用于酒店前场空间的轻量化设计推演与表达机制。其学术价值在于将经验性的酒店大堂设计转化为可复用、可讨论的空间原型与过程证据，为小体量商业室内项目的绩效评估、设计教学及后续循证研究提供了可迁移的知识基础。

## 2. Approach

An end-to-end AI pipeline (see linked playbooks) chains: design intent → 3D model
(10 objects) → construction drawings → BIM (IFC4, 0 products)
→ energy simulation (EnergyPlus) → compliance (—) → BoQ.

Key technical contributions:
- Parametric Blender scene generation with 0 IFC-classified elements
- Automated — compliance verification
- Multi-region BoQ (HK / CN / INTL)

## 3. Deliverables

| Artefact | Count | Format |
|---|:-:|---|
| 3D scene objects | 10 | .blend / .json |
| IFC products | 0 | IFC4 |
| Drawings | 0 | SVG / DXF |
| Stakeholder decks | 0 | PPTX / ODP |
| Exports | 0 |  |

## 4. Impact Metrics

- **Time compression**: 2–4 weeks → — minutes (— speedup)
- **Cost compression**: HK$ 40k–120k → ~HK$ 2k (marginal compute + review)
- **Coverage**: — pass rate against —
- **Energy signal**: EUI = 未模拟; CO₂ offset vs baseline = pending tCO₂/yr
- **Scope**: 42 m² · client type: 客户

## 5. Evidence

- Client testimonial: _[placeholder — pending client interview, see playbooks/CLIENT-INTERVIEW-TEMPLATE.md]_
- Third-party citation: _[placeholder — pending publication / conference]_
- Public artefacts: [portfolio page](../portfolio/smoke-ep-202886.md) · [repo link placeholder]
