> ⚠️ **LIGHT 模式输出** · 数据从 brief/scene 推 · BOQ/EUI/合规/exports 等为占位 · FULL 需走 StartUP-Building P11 pipeline

---
layout: sales-one-pager
id: draft-aa408294
audience: —-prospects
---

# — · 从"需求 → 可施工方案" 10 分钟内

![hero](thumbs/hero.jpg)

_[narrative-sales.txt · LIGHT LLM 调用失败（检查 ZHIZENGZENG_API_KEY）· FULL 需走 StartUP-Building/playbooks/scripts/case-study/narrate.py]_

## 实测结果（本案例）

| 设计耗时 | 交付文件 | 合规通过 |
|:-:|:-:|:-:|
| — 分钟 | 5 份 | — (—) |

## 类似方案



**→ 回复本邮件或扫码 contact us · 48 小时内给你的 — 出第一版。**
